import { createContext } from "react";

const timetableContext = createContext();

export default timetableContext;